namespace abschlussarbeit {
    //hsv(35, 100%, 25%) -> hsv(35, 25%, 100%)
}